INSERT Klient (Imie, Nazwisko) 
VALUES ('Maria', 'Nowak'),('Andrzej','Ropek'),('Mariusz','Banek'),('Ania','Mileska'),('Katarzyna','Oleszko'),('Józef','Kaczmarek');

INSERT Sala(Nr_Sali) 
VALUES (1),(2),(3),(4),(5),(8),(9);
    
INSERT Film(Tytuł, Reżyser, CzasTrwania_minut, RokProdukcji) 
VALUES('Wyspa fantazji', 'Jeff Wadlow', '108', 2020),
	  ('Droga powrotna', "Gavin O'Connor", '108', 2020),
      ('Tenet', "Christopher Nolan", '150', 2020),
      ('The Bridge Curse', "Lester Shih", '88', 2020),
      ('Diabeł wcielony', "Antonio Campos", '139', 2020),
      ('Tyler Rake: Ocalenie', "Sam Hargrave", '117', 2020),
      ('Upadek Grace', "Tyler Perry", '120', 2020);