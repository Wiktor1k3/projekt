SELECT Reżyser,Tytuł
FROM Film
WHERE (RokProdukcji BETWEEN 2018 AND 2021) 
ORDER BY Reżyser;
