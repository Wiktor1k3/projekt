SELECT *
FROM Seans
WHERE MONTH(Data) = 01 AND Id_Film = 3 
ORDER BY Godzina;